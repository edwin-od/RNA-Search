package sample;

public class PrecisionRecall {
    public double precision, recall;

    public PrecisionRecall(double precision, double recall) {
        this.precision = precision;
        this.recall = recall;
    }
}
