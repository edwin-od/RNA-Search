package sample;

public class SimilarityResult {
    double similarity;
    double processingTime;
    double computationTime;

    public SimilarityResult(double similarity, double processingTime, double computationTime) {
        this.similarity = similarity;
        this.processingTime = processingTime;
        this.computationTime = computationTime;
    }
}
