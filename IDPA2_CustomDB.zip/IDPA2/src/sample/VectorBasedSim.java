package sample;

public class VectorBasedSim {
    public VectorBasedSim(){


    }
    static SimilarityResult vectorBasedCosine(String input, String target, boolean TF, boolean IDF) {
        long startTime = System.nanoTime();

        if(!TF && !IDF) {
            return new SimilarityResult(0, 0, 0);
        }

        double[] inputTFs = Frequency.mults(input);     // A,C,G,U
        double[] trgtTFs = Frequency.mults(target);

        double numerator = 0;
        double inputSumSquare  = 0;
        double targetSumSquare = 0;

        for (int i = 0; i < inputTFs.length; i++) {
            double inp = 1, targ = 1;
            if(TF) {
                inp *= inputTFs[i];
                targ *= trgtTFs[i];
            }
            if(IDF) {
                int DF = 0;
                if(inputTFs[i] > 0)
                    DF++;
                if(trgtTFs[i] > 0)
                    DF++;
                double IDFval = DF == 0? 0 : 1- Math.log((double)2/DF);
                inp *= IDFval;
                targ *= IDFval;
            }
            inputTFs[i] = inp;
            trgtTFs[i] = targ;


        }

        long stopTime = System.nanoTime();
        double processingTime = (stopTime - startTime) * Math.pow(10,Main.NANO_CONVERSION);

        startTime = System.nanoTime();

        for(int i=0; i<inputTFs.length; i++) {
            numerator += (inputTFs[i] * trgtTFs[i]);
            inputSumSquare += Math.pow (inputTFs[i], 2);
            targetSumSquare += Math.pow (trgtTFs[i], 2 );
        }
        double similarity = (numerator /Math.sqrt (inputSumSquare * targetSumSquare) );

        stopTime = System.nanoTime();
        double computationTime = (stopTime - startTime) * Math.pow(10,Main.NANO_CONVERSION);

        return new SimilarityResult(similarity, processingTime, computationTime);
    }

    static double vectorBasedCosine(String input, double targetA,double targetC,double targetG,double targetU) {
        double[] inputTFs = Frequency.mults(input);     // A,C,G,U
        double[] trgtTFs = {targetA,targetC,targetG,targetU};

        double numerator = 0;
        double inputSumSquare  = 0;
        double targetSumSquare = 0;

        for (int i = 0; i < inputTFs.length; i++) {

            double inp = inputTFs[i];
            double targ = trgtTFs[i];
            numerator += (inp * targ);
            inputSumSquare += Math.pow (inp, 2);
            targetSumSquare += Math.pow (targ, 2);

        }
        return (numerator /Math.sqrt (inputSumSquare * targetSumSquare) );
    }

    static SimilarityResult vectorBasedEuclidean(String input, String target, boolean TF, boolean IDF) {
        long startTime = System.nanoTime();

        if(!TF && !IDF) {
            return new SimilarityResult(0, 0, 0);
        }

        double[] inputTFs = Frequency.mults(input);     // A,C,G,U
        double[] trgtTFs = Frequency.mults(target);
        double sumSquare  = 0;

        for (int i = 0; i < inputTFs.length; i++) {

            double inp = 1, targ = 1;
            if(TF) {
                inp *= inputTFs[i];
                targ *= trgtTFs[i];
            }
            if(IDF) {
                int DF = 0;
                if(inputTFs[i] > 0)
                    DF++;
                if(trgtTFs[i] > 0)
                    DF++;
                double IDFval = DF == 0? 0 : 1- Math.log((double)2/DF);
                inp *= IDFval;
                targ *= IDFval;
            }
            inputTFs[i] = inp;
            trgtTFs[i] = targ;
        }

        long stopTime = System.nanoTime();
        double processingTime = (stopTime - startTime) * Math.pow(10,Main.NANO_CONVERSION);

        startTime = System.nanoTime();

        for (int i = 0; i < inputTFs.length; i++) {
            sumSquare += Math.pow ((inputTFs[i]-trgtTFs[i]), 2);
        }
        double similarity = (1/(1+Math.sqrt(sumSquare)));

        stopTime = System.nanoTime();
        double computationTime = (stopTime - startTime) * Math.pow(10,Main.NANO_CONVERSION);

        return new SimilarityResult(similarity, processingTime, computationTime);
    }

    static double vectorBasedEuclidean(String input, double targetA,double targetC,double targetG,double targetU) {
        double[] inputTFs = Frequency.mults(input);     // A,C,G,U
        double[] trgtTFs = {targetA,targetC,targetG,targetU};
        double sumSquare  = 0;


        for (int i = 0; i < inputTFs.length; i++) {

            double inp = inputTFs[i];
            double targ = trgtTFs[i];

            sumSquare += Math.pow ((inp-targ), 2);


        }
        return (1/(1+Math.sqrt(sumSquare)));
    }

    static SimilarityResult vectorBasedManhattan(String input, String target, boolean TF, boolean IDF) {
        long startTime = System.nanoTime();

        if(!TF && !IDF) {
            return new SimilarityResult(0, 0, 0);
        }

        double[] inputTFs = Frequency.mults(input);     // A,C,G,U
        double[] trgtTFs = Frequency.mults(target);
        double sumAbs  = 0;


        for (int i = 0; i < inputTFs.length; i++) {
            double inp = 1, targ = 1;
            if(TF) {
                inp *= inputTFs[i];
                targ *= trgtTFs[i];
            }
            if(IDF) {
                int DF = 0;
                if(inputTFs[i] > 0)
                    DF++;
                if(trgtTFs[i] > 0)
                    DF++;
                double IDFval = DF == 0? 0 : 1- Math.log((double)2/DF);
                inp *= IDFval;
                targ *= IDFval;
            }
            inputTFs[i] = inp;
            trgtTFs[i] = targ;
        }

        long stopTime = System.nanoTime();
        double processingTime = (stopTime - startTime) * Math.pow(10,Main.NANO_CONVERSION);

        startTime = System.nanoTime();

        for(int i=0; i<inputTFs.length;i++){
            sumAbs += Math.abs(inputTFs[i]-trgtTFs[i]);
        }
        double similarity = (1/(1+sumAbs));

        stopTime = System.nanoTime();
        double computationTime = (stopTime - startTime) * Math.pow(10,Main.NANO_CONVERSION);

        return new SimilarityResult(similarity, processingTime, computationTime);
    }

    static double vectorBasedManhattan(String input,double targetA,double targetC,double targetG,double targetU) {
        double[] inputTFs = Frequency.mults(input);     // A,C,G,U
        double[] trgtTFs = {targetA,targetC,targetG,targetU};
        double sumAbs  = 0;


        for (int i = 0; i < inputTFs.length; i++) {
            double inp = inputTFs[i];
            double targ = trgtTFs[i];

            sumAbs += Math.abs(inp-targ);


        }
        return (1/(1+sumAbs));
    }

    static SimilarityResult vectorBasedPCC(String input, String target, boolean TF, boolean IDF) {
        long startTime = System.nanoTime();

        if(!TF && !IDF) {
            return new SimilarityResult(0, 0, 0);
        }

        double[] inputTFs = Frequency.mults(input);     // A,C,G,U
        double[] trgtTFs = Frequency.mults(target);
        double numerator = 0;
        double inputSumSquare  = 0;
        double targetSumSquare = 0;
        double inputAvg= 0 ;
        double trgtAvg= 0 ;
        for (int i = 0; i < inputTFs.length; i++) {
            double inp = 1, targ = 1;
            if(TF) {
                inp *= inputTFs[i];
                targ *= trgtTFs[i];
            }
            if(IDF) {
                int DF = 0;
                if(inputTFs[i] > 0)
                    DF++;
                if(trgtTFs[i] > 0)
                    DF++;
                double IDFval = DF == 0? 0 : 1- Math.log((double)2/DF);
                inp *= IDFval;
                targ *= IDFval;
            }
            inputTFs[i] = inp;
            trgtTFs[i] = targ;
        }

        long stopTime = System.nanoTime();
        double processingTime = (stopTime - startTime) * Math.pow(10,Main.NANO_CONVERSION);

        startTime = System.nanoTime();

        for(int i=0; i<inputTFs.length;i++){
            inputAvg+= inputTFs[i];
            trgtAvg+= trgtTFs[i];
        }
        inputAvg /= inputTFs.length;
        trgtAvg /= trgtTFs.length;
        for (int i = 0;i < inputTFs.length; i++){
            numerator += ((inputTFs[i]-inputAvg) * (trgtTFs[i]-trgtAvg));
            inputSumSquare += Math.pow ((inputTFs[i]-inputAvg), 2);
            targetSumSquare += Math.pow ((trgtTFs[i]-trgtAvg), 2 );

        }
        double similarity = (numerator /Math.sqrt (inputSumSquare * targetSumSquare));

        stopTime = System.nanoTime();
        double computationTime = (stopTime - startTime) * Math.pow(10,Main.NANO_CONVERSION);

        return new SimilarityResult(similarity, processingTime, computationTime);
    }
    static double vectorBasedPCC(String input,double targetA,double targetC,double targetG,double targetU) {
        double[] inputTFs = Frequency.mults(input);     // A,C,G,U
        double[] trgtTFs = {targetA,targetC,targetG,targetU};
        double numerator = 0;
        double inputSumSquare  = 0;
        double targetSumSquare = 0;
        double inputAvg= 0 ;
        double trgtAvg= 0 ;
        for (int i = 0; i < inputTFs.length; i++) {
            inputAvg+= inputTFs[i] ;
            trgtAvg+= trgtTFs[i] ;
        }
        inputAvg /= inputTFs.length;
        trgtAvg /= trgtTFs.length;
        for (int i = 0;i < inputTFs.length; i++){
            numerator += ((inputTFs[i]-inputAvg) * (trgtTFs[i]-trgtAvg));
            inputSumSquare += Math.pow ((inputTFs[i]-inputAvg), 2);
            targetSumSquare += Math.pow ((trgtTFs[i]-trgtAvg), 2 );

        }
        return (numerator /Math.sqrt (inputSumSquare * targetSumSquare) );
    }

}
