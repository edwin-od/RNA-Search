package sample;

public class Literal {
    private char name;
    private String canBe;

    public Literal(char name) {
        this.name = name;
        this.fill();
    }

    public char getName() {
        return this.name;
    }

    public void setName(char name) {
        this.name = name;
    }

    public String getCanBe() {
        return this.canBe;
    }

    public void setCanBe(String canBe) {
        this.canBe = canBe;
    }

    private void fill() {
        if (this.name == 'A' || this.name == 'C' || this.name == 'U' || this.name == 'G') {
            this.canBe = this.name + "";
        }

        if (this.name == 'R') {
            this.canBe = "GA";
        }

        if (this.name == 'M') {
            this.canBe = "AC";
        }

        if (this.name == 'S') {
            this.canBe = "GC";
        }

        if (this.name == 'V') {
            this.canBe = "GCA";
        }

        if (this.name == 'N') {
            this.canBe = "AGCU";
        }

    }
}
