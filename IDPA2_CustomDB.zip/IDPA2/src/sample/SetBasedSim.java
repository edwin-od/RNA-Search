package sample;

public class SetBasedSim {
    public SetBasedSim(){

    }
    static SimilarityResult setBasedInter(String input, String target ){
        long startTime = System.nanoTime();

        double[] arrInput = Frequency.mults(input);     // A,C,G,U
        double[] arrTrgt = Frequency.mults(target);

        long stopTime = System.nanoTime();
        double processingTime = (stopTime - startTime) * Math.pow(10,Main.NANO_CONVERSION);

        startTime = System.nanoTime();

        double intersection=0 ;
        double inputMults=0;
        double targetMults=0;
        for ( int i=0 ; i< arrInput.length ; i++){
            intersection+=Math.min(arrInput[i], arrTrgt[i]);
            inputMults+= arrInput[i] ;
            targetMults+= arrTrgt[i] ;

        }
        double similarity = (intersection/Math.min(inputMults,targetMults));

        stopTime = System.nanoTime();
        double computationTime = (stopTime - startTime) * Math.pow(10,Main.NANO_CONVERSION);

        return new SimilarityResult(similarity, processingTime, computationTime);

    }
    static double setBasedInter(String input,double targetA,double targetC,double targetG,double targetU){
        double[] arrInput = Frequency.mults(input);     // A,C,G,U
        double[] arrTrgt = {targetA,targetC,targetG,targetU};
        double intersection=0 ;
        double inputMults=0;
        double targetMults=0;
        for ( int i=0 ; i< arrInput.length ; i++){
            intersection+=Math.min(arrInput[i], arrTrgt[i]);
            inputMults+= arrInput[i] ;
            targetMults+= arrTrgt[i] ;

        }
        return (intersection/Math.min(inputMults,targetMults));

    }
    static SimilarityResult setBasedJaccard(String input, String target ) {
        long startTime = System.nanoTime();

        double[] arrInput = Frequency.mults(input);     // A,C,G,U
        double[] arrTrgt = Frequency.mults(target);

        long stopTime = System.nanoTime();
        double processingTime = (stopTime - startTime) * Math.pow(10,Main.NANO_CONVERSION);

        startTime = System.nanoTime();

        double intersection = 0;
        double inputMults = 0;
        double targetMults = 0;
        for (int i = 0; i < arrInput.length; i++) {
            intersection += Math.min(arrInput[i], arrTrgt[i]);
            inputMults += arrInput[i];
            targetMults += arrTrgt[i];

        }
        double similarity = (intersection / ((inputMults + targetMults) - intersection));

        stopTime = System.nanoTime();
        double computationTime = (stopTime - startTime) * Math.pow(10,Main.NANO_CONVERSION);

        return new SimilarityResult(similarity, processingTime, computationTime);
    }
    static double setBasedJaccard(String input,double targetA,double targetC,double targetG,double targetU) {
        double[] arrInput = Frequency.mults(input);     // A,C,G,U
        double[] arrTrgt = {targetA,targetC,targetG,targetU};
        double intersection = 0;
        double inputMults = 0;
        double targetMults = 0;
        for (int i = 0; i < arrInput.length; i++) {
            intersection += Math.min(arrInput[i], arrTrgt[i]);
            inputMults += arrInput[i];
            targetMults += arrTrgt[i];

        }
        return (intersection / ((inputMults + targetMults) - intersection));
    }

    static SimilarityResult setBasedDice(String input, String target ) {
        long startTime = System.nanoTime();

        double[] arrInput = Frequency.mults(input);      // A,C,G,U
        double[] arrTrgt = Frequency.mults(target);

        long stopTime = System.nanoTime();
        double processingTime = (stopTime - startTime) * Math.pow(10,Main.NANO_CONVERSION);

        startTime = System.nanoTime();

        double intersection = 0;
        double inputMults = 0;
        double targetMults = 0;
        for (int i = 0; i < arrInput.length; i++) {
            intersection += Math.min(arrInput[i], arrTrgt[i]);
            inputMults += arrInput[i];
            targetMults += arrTrgt[i];

        }
        double similarity = (2*intersection / (inputMults + targetMults));

        stopTime = System.nanoTime();
        double computationTime = (stopTime - startTime) * Math.pow(10,Main.NANO_CONVERSION);

        return new SimilarityResult(similarity, processingTime, computationTime);
    }
    static double setBasedDice(String input,double targetA,double targetC,double targetG,double targetU) {
        double[] arrInput = Frequency.mults(input);      // A,C,G,U
        double[] arrTrgt = {targetA,targetC,targetG,targetU};
        double intersection = 0;
        double inputMults = 0;
        double targetMults = 0;
        for (int i = 0; i < arrInput.length; i++) {
            intersection += Math.min(arrInput[i], arrTrgt[i]);
            inputMults += arrInput[i];
            targetMults += arrTrgt[i];

        }
        return (2*intersection / (inputMults + targetMults) );
    }
}
