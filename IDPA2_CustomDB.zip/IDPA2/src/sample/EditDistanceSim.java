package sample;

public class EditDistanceSim {
    public EditDistanceSim(){

    }
    static SimilarityResult getSimilarityED(String input, String target, double insWeight, double delWeight, double updWeight){
        long startTime = System.nanoTime();

        double editDistance = EditDistanceSim.getED(input, target, insWeight, delWeight, updWeight);

        long stopTime = System.nanoTime();
        double processingTime = (stopTime - startTime) * Math.pow(10,Main.NANO_CONVERSION);

        startTime = System.nanoTime();

        double similarity = 1/(1+editDistance);

        stopTime = System.nanoTime();
        double computationTime = (stopTime - startTime) * Math.pow(10,Main.NANO_CONVERSION);

        return new SimilarityResult(similarity, processingTime, computationTime);
    }

    static double getED(String input, String target, double insWeight, double delWeight, double updWeight){
        int l1 = target.length();
        int l2 = input.length();

        if (l1 == 0)
            return l2;

        if (l2 == 0)
            return l1;

        double  arr[][] = new double[l1 + 1][l2 + 1];

        for (int i = 0; i <= l1; i++)
            arr[i][0] = i;

        for (int j = 0; j <= l2; j++)
            arr[0][j] = j;

        for (int i = 1; i <= l1; i++) {
            char ch1 = target.charAt(i - 1);
            Literal tgtlit = new Literal(ch1);

            for (int j = 1; j <= l2; j++) {
                char ch2 = input.charAt(j - 1);
                Literal inptlit = new Literal(ch2);
                double commons=0;
                for (int x=0 ; x<tgtlit.getCanBe().length();x++) {
                    commons += inptlit.getCanBe().contains(tgtlit.getCanBe().charAt(x)+"") ? 1:0 ;
                }
                double newUpdtWeight = ch1 == ch2 ? 0 : updWeight*(1-((commons/inptlit.getCanBe().length())*(commons/tgtlit.getCanBe().length())));
                arr[i][j] = Math.min(
                        Math.min((arr[i - 1][j] + delWeight),
                                (arr[i][j - 1] + insWeight)),
                        arr[i - 1][j - 1] + newUpdtWeight);
            }
        }

        return arr[l1][l2];


    }
}
