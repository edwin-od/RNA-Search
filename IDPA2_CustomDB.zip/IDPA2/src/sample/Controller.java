package sample;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.chart.LineChart;
import javafx.scene.chart.NumberAxis;
import javafx.scene.chart.XYChart;
import javafx.scene.control.*;

import java.net.URL;
import java.util.ArrayList;
import java.util.ResourceBundle;

public class Controller implements Initializable {

    @FXML
    TextField sequence1, sequence2, insWeight, delWeight, updtWeight, dbPath, insWeightSE, delWeightSE, updtWeightSE, searchField;

    @FXML
    Label edsimLabel, edprocLabel, edCalcLabel,
            interSimLabel, interProcLabel, interCalcLabel, jacSimLabel, JacProcLabel, JacCalcLabel, diceSimLabel, diceProcLabel, diceCalcLabel,
            cosSimLabel, cosProcLabel, cosCalcLabel, euclSimLabel, euclProcLabel, euclCalcLabel, manhSimLabel, manhProcLabel, manhCalcLabel, pccSimLabel, pccProcLabel, pccCalcLabel,
            edSequenceLabel, interSequenceLabel, jaccSequenceLabel, diceSequenceLabel, cosSequenceLabel, euclSeqLabel, manSequenceLabel, pccSequenceLabel,
            edFval, interFval, jacFval, diceFval, cosFval, euclFval, manhFval, pccFval,
            edMapVal, interMapVal, jacMapVal, diceMapVal, cosMapVal, eucMapVal, manhMapVal, pccMapVal;

    @FXML
    ScrollPane edScroll, intScroll, jacScroll, diceScroll, cosScroll, eucScroll, manhScroll, pccScroll;

    @FXML
    LineChart edGraph, interGraph, jacGraph, diceGraph, cosGraph, eucGraph, manhGraph, pccGraph;

    @FXML
    NumberAxis edR, interR, jacR, diceR, cosR, eucR, manhR, pccR, edPR, interPR, jacPR, dicePR, cosPR, eucPR, manhPR, pccPR;

    XYChart.Series edSeries, interSeries, jacSeries, diceSeries, cosSeries, eucSeries, manhSeries, pccSeries;

    @FXML
    RadioButton nanosecRb, microsecRb, millisecRb, secRb;

    @FXML
    ToggleGroup timescale;

    @FXML
    CheckBox cosTF, cosIDF, euclTF, euclIDF, manhTF, manhIDF, pccTF, pccIDF,
            editDistanceCheck, interCheck, jaccardCheck, diceCheck, cosineCheck, euclCheck, manhCheck, pccCheck;

    @FXML
    Slider kSlider, minSimSlider;


    @Override
    public void initialize(URL arg0, ResourceBundle arg1) {
        edGraph.setAnimated(false);
        edSeries = new XYChart.Series();
        edSeries.getData().clear();
        edGraph.getData().add(edSeries);

        interGraph.setAnimated(false);
        interSeries = new XYChart.Series();
        interSeries.getData().clear();
        interGraph.getData().add(interSeries);

        jacGraph.setAnimated(false);
        jacSeries = new XYChart.Series();
        jacSeries.getData().clear();
        jacGraph.getData().add(jacSeries);

        diceGraph.setAnimated(false);
        diceSeries = new XYChart.Series();
        diceSeries.getData().clear();
        diceGraph.getData().add(diceSeries);

        cosGraph.setAnimated(false);
        cosSeries = new XYChart.Series();
        cosSeries.getData().clear();
        cosGraph.getData().add(cosSeries);

        eucGraph.setAnimated(false);
        eucSeries = new XYChart.Series();
        eucSeries.getData().clear();
        eucGraph.getData().add(eucSeries);

        manhGraph.setAnimated(false);
        manhSeries = new XYChart.Series();
        manhSeries.getData().clear();
        manhGraph.getData().add(manhSeries);

        pccGraph.setAnimated(false);
        pccSeries = new XYChart.Series();
        pccSeries.getData().clear();
        pccGraph.getData().add(pccSeries);

        resetScrollPanes();

        timescale = new ToggleGroup();
        nanosecRb.setToggleGroup(timescale);
        microsecRb.setToggleGroup(timescale);
        millisecRb.setToggleGroup(timescale);
        secRb.setToggleGroup(timescale);
    }

    @FXML
    public void calculate_ed(ActionEvent event){
        boolean parametersSuccess = checkSetParameterSuccess();
        try {
            if(insWeight.getText().length() == 0) {
                insWeight.setText("1");
                Main.INSERT_WEIGHT = 1;
                parametersSuccess = false;
            }
            Main.INSERT_WEIGHT = Double.parseDouble(insWeight.getText());
        } catch (NumberFormatException nfe) {
            Main.INSERT_WEIGHT = 1;
            insWeight.setText("1");
            parametersSuccess = false;
        }
        try {
            if(delWeight.getText().length() == 0) {
                delWeight.setText("1");
                Main.DELETE_WEIGHT = 1;
                parametersSuccess = false;
            }
            Main.DELETE_WEIGHT = Double.parseDouble(delWeight.getText());
        } catch (NumberFormatException nfe) {
            Main.DELETE_WEIGHT = 1;
            delWeight.setText("1");
            parametersSuccess = false;
        }
        try {
            if(updtWeight.getText().length() == 0) {
                updtWeight.setText("1");
                Main.UPDATE_WEIGHT = 1;
                parametersSuccess = false;
            }
            Main.UPDATE_WEIGHT = Double.parseDouble(updtWeight.getText());
        } catch (NumberFormatException nfe) {
            Main.UPDATE_WEIGHT = 1;
            updtWeight.setText("1");
            parametersSuccess = false;
        }

        if(parametersSuccess) {
            System.out.println();
            SimilarityResult edRes = EditDistanceSim.getSimilarityED(sequence1.getText().toUpperCase(), sequence2.getText().toUpperCase(), Main.INSERT_WEIGHT, Main.DELETE_WEIGHT, Main.UPDATE_WEIGHT);
            edsimLabel.setText(formatDouble(edRes.similarity));
            edprocLabel.setText(formatDouble(edRes.processingTime));
            edCalcLabel.setText(formatDouble(edRes.computationTime));
        } else {
            edsimLabel.setText("");
            edprocLabel.setText("");
            edCalcLabel.setText("");
        }

    }

    @FXML
    public void calculate_inter(ActionEvent event){
        boolean parametersSuccess = checkSetParameterSuccess();
        if(parametersSuccess) {
            SimilarityResult interRes = SetBasedSim.setBasedInter(sequence1.getText().toUpperCase(), sequence2.getText().toUpperCase());
            interSimLabel.setText(formatDouble(interRes.similarity));
            interProcLabel.setText(formatDouble(interRes.processingTime));
            interCalcLabel.setText(formatDouble(interRes.computationTime));
        } else {
            interSimLabel.setText("");
            interProcLabel.setText("");
            interCalcLabel.setText("");
        }

    }

    @FXML
    public void calculate_jacc(ActionEvent event){
        boolean parametersSuccess = checkSetParameterSuccess();

        if(parametersSuccess) {
            SimilarityResult jaccRes = SetBasedSim.setBasedJaccard(sequence1.getText().toUpperCase(), sequence2.getText().toUpperCase());
            jacSimLabel.setText(formatDouble(jaccRes.similarity));
            JacProcLabel.setText(formatDouble(jaccRes.processingTime));
            JacCalcLabel.setText(formatDouble(jaccRes.computationTime));
        } else {
            jacSimLabel.setText("");
            JacProcLabel.setText("");
            JacCalcLabel.setText("");
        }

    }

    @FXML
    public void calculate_dice(ActionEvent event){
        boolean parametersSuccess = checkSetParameterSuccess();

        if(parametersSuccess) {
            SimilarityResult diceRes = SetBasedSim.setBasedDice(sequence1.getText().toUpperCase(), sequence2.getText().toUpperCase());
            diceSimLabel.setText(formatDouble(diceRes.similarity));
            diceProcLabel.setText(formatDouble(diceRes.processingTime));
            diceCalcLabel.setText(formatDouble(diceRes.computationTime));
        } else {
            diceSimLabel.setText("");
            diceProcLabel.setText("");
            diceCalcLabel.setText("");
        }

    }

    @FXML
    public void calculate_cos(ActionEvent event){
        boolean parametersSuccess = checkSetParameterSuccess();

        if(parametersSuccess) {
            Main.USE_COS_TF = cosTF.isSelected();
            Main.USE_COS_IDF = cosIDF.isSelected();
            SimilarityResult cosRes = VectorBasedSim.vectorBasedCosine(sequence1.getText().toUpperCase(), sequence2.getText().toUpperCase(), Main.USE_COS_TF, Main.USE_COS_IDF);
            cosSimLabel.setText(formatDouble(cosRes.similarity));
            cosProcLabel.setText(formatDouble(cosRes.processingTime));
            cosCalcLabel.setText(formatDouble(cosRes.computationTime));
        } else {
            cosSimLabel.setText("");
            cosProcLabel.setText("");
            cosCalcLabel.setText("");
        }

    }

    @FXML
    public void calculate_euc(ActionEvent event){
        boolean parametersSuccess = checkSetParameterSuccess();

        if(parametersSuccess) {
            Main.USE_EUC_TF = euclTF.isSelected();
            Main.USE_EUC_IDF = euclIDF.isSelected();
            SimilarityResult encRes = VectorBasedSim.vectorBasedEuclidean(sequence1.getText().toUpperCase(), sequence2.getText().toUpperCase(), Main.USE_EUC_TF, Main.USE_EUC_IDF);
            euclSimLabel.setText(formatDouble(encRes.similarity));
            euclProcLabel.setText(formatDouble(encRes.processingTime));
            euclCalcLabel.setText(formatDouble(encRes.computationTime));
        } else {
            euclSimLabel.setText("");
            euclProcLabel.setText("");
            euclCalcLabel.setText("");
        }

    }

    @FXML
    public void calculate_manh(ActionEvent event){
        boolean parametersSuccess = checkSetParameterSuccess();

        if(parametersSuccess) {
            Main.USE_MANH_TF = manhTF.isSelected();
            Main.USE_MANH_IDF = manhIDF.isSelected();
            SimilarityResult manhRes = VectorBasedSim.vectorBasedManhattan(sequence1.getText().toUpperCase(), sequence2.getText().toUpperCase(), Main.USE_MANH_TF, Main.USE_MANH_IDF);
            manhSimLabel.setText(formatDouble(manhRes.similarity));
            manhProcLabel.setText(formatDouble(manhRes.processingTime));
            manhCalcLabel.setText(formatDouble(manhRes.computationTime));
        } else {
            manhSimLabel.setText("");
            manhProcLabel.setText("");
            manhCalcLabel.setText("");
        }

    }

    @FXML
    public void calculate_pcc(ActionEvent event){
        boolean parametersSuccess = checkSetParameterSuccess();

        if(parametersSuccess) {
            Main.USE_PCC_TF = pccTF.isSelected();
            Main.USE_PCC_IDF = pccIDF.isSelected();
            SimilarityResult pccRes = VectorBasedSim.vectorBasedPCC(sequence1.getText().toUpperCase(), sequence2.getText().toUpperCase(), Main.USE_PCC_TF, Main.USE_PCC_IDF);
            pccSimLabel.setText(formatDouble(pccRes.similarity));
            pccProcLabel.setText(formatDouble(pccRes.processingTime));
            pccCalcLabel.setText(formatDouble(pccRes.computationTime));
        } else {
            pccSimLabel.setText("");
            pccProcLabel.setText("");
            pccCalcLabel.setText("");
        }

    }

    @FXML
    public void search(ActionEvent event){
        clearAllResults();
        clearAllCharts();
        clearAllFValues();
        clearAllMAPs();
        resetScrollPanes();

        boolean parametersSuccess = true;
        try {
            if(insWeightSE.getText().length() == 0) {
                insWeightSE.setText("0.1");
                Main.INSERT_WEIGHT_SE = 0.1;
                parametersSuccess = false;
            }
            Main.INSERT_WEIGHT_SE = Double.parseDouble(insWeightSE.getText());
        } catch (NumberFormatException nfe) {
            Main.INSERT_WEIGHT_SE = 0.1;
            insWeightSE.setText("0.1");
            parametersSuccess = false;
        }
        try {
            if(delWeightSE.getText().length() == 0) {
                delWeightSE.setText("0.1");
                Main.DELETE_WEIGHT_SE = 0.1;
                parametersSuccess = false;
            }
            Main.DELETE_WEIGHT_SE = Double.parseDouble(delWeightSE.getText());
        } catch (NumberFormatException nfe) {
            Main.DELETE_WEIGHT_SE = 0.1;
            delWeightSE.setText("0.1");
            parametersSuccess = false;
        }
        try {
            if(updtWeightSE.getText().length() == 0) {
                updtWeightSE.setText("0.1");
                Main.UPDATE_WEIGHT_SE = 0.1;
                parametersSuccess = false;
            }
            Main.UPDATE_WEIGHT_SE = Double.parseDouble(updtWeightSE.getText());
        } catch (NumberFormatException nfe) {
            Main.UPDATE_WEIGHT_SE = 0.1;
            updtWeightSE.setText("0.1");
            parametersSuccess = false;
        }
        if(!isSequenceRNA(searchField.getText())) {
            parametersSuccess = false;
            searchField.setText("");
        }

        Main.DB_PATH = dbPath.getText();

        Main.K = (int)Math.round(kSlider.getValue());
        Main.MIN_SIMILARITY = minSimSlider.getValue();

        Main.USE_EDIT_DISTANCE = editDistanceCheck.isSelected();
        Main.USE_INTERSECTION = interCheck.isSelected();
        Main.USE_JACCARD = jaccardCheck.isSelected();
        Main.USE_DICE = diceCheck.isSelected();
        Main.USE_COSINE = cosineCheck.isSelected();
        Main.USE_EUCLIDEAN = euclCheck.isSelected();
        Main.USE_MANHATTAN = manhCheck.isSelected();
        Main.USE_PCC = pccCheck.isSelected();

        if(parametersSuccess) {
            ArrayList<ArrayList<SearchResult>> searchResults = SearchEngine.search(
                    searchField.getText().toUpperCase(),
                    Main.USE_EDIT_DISTANCE,
                    Main.USE_INTERSECTION,Main.USE_JACCARD,Main.USE_DICE,
                    Main.USE_COSINE,Main.USE_EUCLIDEAN,Main.USE_MANHATTAN,Main.USE_PCC,
                    Main.MIN_SIMILARITY, Main.K
            );

            if(searchResults.size() > 0) {
                populateResult(edSequenceLabel, searchResults.get(0));
                populateResult(interSequenceLabel, searchResults.get(1));
                populateResult(jaccSequenceLabel, searchResults.get(2));
                populateResult(diceSequenceLabel, searchResults.get(3));
                populateResult(cosSequenceLabel, searchResults.get(4));
                populateResult(euclSeqLabel, searchResults.get(5));
                populateResult(manSequenceLabel, searchResults.get(6));
                populateResult(pccSequenceLabel, searchResults.get(7));
            } else {
                clearAllResults();
            }

            if(SearchEngine.PR_R_GRAPH.size() > 0) {
                populateChart(edGraph, edSeries, SearchEngine.PR_R_GRAPH.get(0));
                populateChart(interGraph, interSeries, SearchEngine.PR_R_GRAPH.get(1));
                populateChart(jacGraph, jacSeries, SearchEngine.PR_R_GRAPH.get(2));
                populateChart(diceGraph, diceSeries, SearchEngine.PR_R_GRAPH.get(3));
                populateChart(cosGraph, cosSeries, SearchEngine.PR_R_GRAPH.get(4));
                populateChart(eucGraph, eucSeries, SearchEngine.PR_R_GRAPH.get(5));
                populateChart(manhGraph, manhSeries, SearchEngine.PR_R_GRAPH.get(6));
                populateChart(pccGraph, pccSeries, SearchEngine.PR_R_GRAPH.get(7));
            } else {
                clearAllCharts();
            }

            if(SearchEngine.F_VALUE.length == 8) {
                edFval.setText(formatDouble(SearchEngine.F_VALUE[0]));
                interFval.setText(formatDouble(SearchEngine.F_VALUE[1]));
                jacFval.setText(formatDouble(SearchEngine.F_VALUE[2]));
                diceFval.setText(formatDouble(SearchEngine.F_VALUE[3]));
                cosFval.setText(formatDouble(SearchEngine.F_VALUE[4]));
                euclFval.setText(formatDouble(SearchEngine.F_VALUE[5]));
                manhFval.setText(formatDouble(SearchEngine.F_VALUE[6]));
                pccFval.setText(formatDouble(SearchEngine.F_VALUE[7]));
            } else {
                clearAllFValues();
            }

            if(SearchEngine.MEAN_AVERAGE_PR.length == 8) {
                edMapVal.setText(formatDouble(SearchEngine.MEAN_AVERAGE_PR[0]));
                interMapVal.setText(formatDouble(SearchEngine.MEAN_AVERAGE_PR[1]));
                jacMapVal.setText(formatDouble(SearchEngine.MEAN_AVERAGE_PR[2]));
                diceMapVal.setText(formatDouble(SearchEngine.MEAN_AVERAGE_PR[3]));
                cosMapVal.setText(formatDouble(SearchEngine.MEAN_AVERAGE_PR[4]));
                eucMapVal.setText(formatDouble(SearchEngine.MEAN_AVERAGE_PR[5]));
                manhMapVal.setText(formatDouble(SearchEngine.MEAN_AVERAGE_PR[6]));
                pccMapVal.setText(formatDouble(SearchEngine.MEAN_AVERAGE_PR[7]));
            } else {
                clearAllMAPs();
            }
        } else {
            clearAllResults();
            clearAllCharts();
            clearAllFValues();
            clearAllMAPs();
        }
    }

    private void populateChart(LineChart lc, XYChart.Series s, ArrayList<PrecisionRecall> data) {
        if(data == null || data.size() == 0) {
            s.getData().clear();
            return;
        }
        if(lc.getData().size() == 0)
            lc.getData().add(s);
        for(int i=0; i<data.size(); i++) {
            s.getData().add(new XYChart.Data(data.get(i).recall, data.get(i).precision));
        }
    }

    private void populateResult(Label l, ArrayList<SearchResult> sr) {
        for(int i=0; i<sr.size(); i++) {
            l.setText(l.getText()+(i+1)+") " + sr.get(i).sequence+"\n--> sim = "+formatDouble(sr.get(i).similarity)+"\n");

        }
    }

    private void clearAllResults() {
        edSequenceLabel.setText("");
        interSequenceLabel.setText("");
        jaccSequenceLabel.setText("");
        diceSequenceLabel.setText("");
        cosSequenceLabel.setText("");
        euclSeqLabel.setText("");
        manSequenceLabel.setText("");
        pccSequenceLabel.setText("");
    }

    private void clearAllCharts() {
        edSeries.getData().clear();
        edGraph.getData().clear();

        interSeries.getData().clear();
        interGraph.getData().clear();

        jacSeries.getData().clear();
        jacGraph.getData().clear();

        diceSeries.getData().clear();
        diceGraph.getData().clear();

        cosSeries.getData().clear();
        cosGraph.getData().clear();

        eucSeries.getData().clear();
        eucGraph.getData().clear();

        manhSeries.getData().clear();
        manhGraph.getData().clear();

        pccSeries.getData().clear();
        pccGraph.getData().clear();
    }

    private void clearAllFValues() {
        edFval.setText("");
        interFval.setText("");
        jacFval.setText("");
        diceFval.setText("");
        cosFval.setText("");
        euclFval.setText("");
        manhFval.setText("");
        pccFval.setText("");
    }

    private void clearAllMAPs() {
        edMapVal.setText("");
        interMapVal.setText("");
        jacMapVal.setText("");
        diceMapVal.setText("");
        cosMapVal.setText("");
        eucMapVal.setText("");
        manhMapVal.setText("");
        pccMapVal.setText("");
    }

    private void resetScrollPanes() {
        edScroll.setVvalue(0);
        edScroll.setHvalue(0);

        intScroll.setVvalue(0);
        intScroll.setHvalue(0);

        jacScroll.setVvalue(0);
        jacScroll.setHvalue(0);

        diceScroll.setVvalue(0);
        diceScroll.setHvalue(0);

        cosScroll.setVvalue(0);
        cosScroll.setHvalue(0);

        eucScroll.setVvalue(0);
        eucScroll.setHvalue(0);

        manhScroll.setVvalue(0);
        manhScroll.setHvalue(0);

        pccScroll.setVvalue(0);
        pccScroll.setHvalue(0);
    }

    private boolean isSequenceRNA(String sequence) {
        if(sequence.length() == 0)
            return false;
        sequence = sequence.toUpperCase();
        for(int i = 0; i < sequence.length(); i++) {
            if(sequence.charAt(i) != 'A' && sequence.charAt(i) != 'C' && sequence.charAt(i) != 'G' && sequence.charAt(i) != 'U'
                    && sequence.charAt(i) != 'R' && sequence.charAt(i) != 'M' && sequence.charAt(i) != 'S' && sequence.charAt(i) != 'V' && sequence.charAt(i) != 'N') {
                return false;
            }
        }
        return true;
    }

    private boolean checkSetParameterSuccess() {
        boolean parametersSuccess = true;
        RadioButton timeSelected = (RadioButton)timescale.getSelectedToggle();
        switch(timeSelected.getText()) {
            case "ns":
                Main.NANO_CONVERSION = 0;
                break;
            case "us":
                Main.NANO_CONVERSION = -3;
                break;
            case "ms":
                Main.NANO_CONVERSION = -6;
                break;
            case "s":
                Main.NANO_CONVERSION = -9;
                break;
            default:
                break;
        }

        if(!isSequenceRNA(sequence1.getText())) {
            parametersSuccess = false;
            sequence1.setText("");
        }
        if(!isSequenceRNA((sequence2.getText()))) {
            parametersSuccess = false;
            sequence2.setText("");
        }
        return parametersSuccess;
    }

    private String formatDouble(double d) {
        if(Double.isNaN(d))
            return "0.0";
        String s = d+"", r = "";
        boolean decReached = false, finished = false;
        for(int i=0; i<s.length(); i++) {
            if(!decReached && s.charAt(i) == '.') {
                decReached = true;
                r += '.';
                int counter = 0;
                for(int j=i+1; j<s.length(); j++) {
                    if(counter < Main.DECIMALS && s.charAt(j) != 'E') {
                        r += s.charAt(j);
                        finished = true;
                        counter++;
                    } else {
                        if(s.charAt(j) == 'E') {
                            for(int x = r.length()-1; x > 0; x--) {
                                if(r.charAt(x) == '.') {
                                    r += "0";
                                    break;
                                }
                                if(r.charAt(x) != '0')
                                    break;
                                r = r.substring(0, x);
                            }
                            int offset = 1;
                            String temp = r + s.substring(j);
                            if(temp.substring(temp.indexOf('.')+1, temp.indexOf('E')).length() < Main.DECIMALS)
                                offset = 0;
                            return r.substring(0, r.length()-offset) + s.substring(j);
                        }
                        continue;
                    }
                }
            } else if(!finished) {
                r += s.charAt(i);
            }
        }
        for(int x = r.length()-1; x > 0; x--) {
            if(r.charAt(x) == '.') {
                r += "0";
                break;
            }
            if(r.charAt(x) != '0')
                break;
            r = r.substring(0, x);
        }
        return r;
    }
}
