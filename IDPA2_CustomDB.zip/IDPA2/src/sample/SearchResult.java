package sample;

public class SearchResult {
    public String sequence;
    public double similarity;
    public boolean isRelevant;

    public SearchResult(String sequence, double similarity, boolean isRelevant) {
        this.sequence = sequence;
        this.similarity = similarity;
        this.isRelevant = isRelevant;
    }
}
