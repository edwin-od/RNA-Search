package sample;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.RadioButton;
import javafx.stage.Stage;
import org.w3c.dom.Attr;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import java.io.File;
import java.util.ArrayList;

public class Main extends Application {
    static final public int MIN_DB_SEQ_SIZE = 2, MAX_DB_SEQ_SIZE = 8;

    static public String DB_PATH = "db.xml";

    static final public int DECIMALS = 3;

    static final public int DB_SIZE = 1000;

    static public double INSERT_WEIGHT = 1;
    static public double INSERT_WEIGHT_SE = 1;

    static public double DELETE_WEIGHT = 1;
    static public double DELETE_WEIGHT_SE = 1;

    static public double UPDATE_WEIGHT = 1;
    static public double UPDATE_WEIGHT_SE = 1;

    static public int NANO_CONVERSION = -3; // 0->ns  |  -3->us  |  -6->ms   |  -9->s

    static public boolean USE_EDIT_DISTANCE = true;
    static public boolean USE_INTERSECTION = true, USE_JACCARD = true, USE_DICE = true;
    static public boolean USE_COSINE = true, USE_EUCLIDEAN = true, USE_MANHATTAN = true, USE_PCC = true;


    static public double MIN_SIMILARITY = 0.4;
    static public int K = 20;


    static public boolean USE_COS_TF = true, USE_COS_IDF = false;
    static public boolean USE_EUC_TF = true, USE_EUC_IDF = false;
    static public boolean USE_MANH_TF = true, USE_MANH_IDF = false;
    static public boolean USE_PCC_TF = true, USE_PCC_IDF = false;

    public static void main(String[] args){

        //XMLfill(Main.MAX_DB_SEQ_SIZE,Main.MIN_DB_SEQ_SIZE);   // Creating the RNA Database and pre-processing it

        launch(args);

        /*
        double insWeight,delWeight,updWeight;
        String targetRNA, inputRNA;
        insWeight= INSERT_WEIGHT;
        delWeight= DELETE_WEIGHT;
        updWeight= UPDATE_WEIGHT;
        targetRNA = "ACCG";
        inputRNA = "GRSSSS";

        String timeUnit = "ns";
        switch(Main.NANO_CONVERSION) {
            case -3:
                timeUnit = "us";
                break;
            case -6:
                timeUnit = "ms";
                break;
            case -9:
                timeUnit = "s";
                break;
            default:
                timeUnit = "ns";
                break;

        }


        System.out.println();

        SimilarityResult edRes = EditDistanceSim.getSimilarityED(inputRNA, targetRNA,insWeight,delWeight,updWeight);
        System.out.println("- Edit Distance Similarity : " + edRes.similarity + " (Tp= "+ edRes.processingTime+" "+timeUnit+" , Tc= "+ edRes.computationTime +" "+timeUnit+")");

        SimilarityResult interRes = SetBasedSim.setBasedInter(inputRNA,targetRNA);
        System.out.println("- Set based Interection normalized : "+  interRes.similarity + " (Tp= "+ interRes.processingTime+" "+timeUnit+" , Tc= "+ interRes.computationTime +" "+timeUnit+")");

        SimilarityResult jaccRes = SetBasedSim.setBasedJaccard(inputRNA,targetRNA);
        System.out.println("- Set based Jaccard normalized : "+ jaccRes.similarity + " (Tp= "+ jaccRes.processingTime+" "+timeUnit+" , Tc= "+ jaccRes.computationTime +" "+timeUnit+")");

        SimilarityResult diceRes = SetBasedSim.setBasedDice(inputRNA,targetRNA);
        System.out.println("- Set based Dice normalized : "+  diceRes.similarity + " (Tp= "+ diceRes.processingTime+" "+timeUnit+" , Tc= "+ diceRes.computationTime +" "+timeUnit+")");

        SimilarityResult cosRes = VectorBasedSim.vectorBasedCosine(inputRNA,targetRNA, Main.USE_COS_TF, Main.USE_COS_IDF);
        System.out.println("- Vector based Cosine : "+  cosRes.similarity + " (Tp= "+ cosRes.processingTime+" "+timeUnit+" , Tc= "+ cosRes.computationTime +" "+timeUnit+")");

        SimilarityResult encRes = VectorBasedSim.vectorBasedEuclidean(inputRNA,targetRNA, Main.USE_EUC_TF, Main.USE_EUC_IDF);
        System.out.println("- Vector based Euclidean distance : "+  encRes.similarity + " (Tp= "+ encRes.processingTime+" "+timeUnit+" , Tc= "+ encRes.computationTime +" "+timeUnit+")");

        SimilarityResult manhRes = VectorBasedSim.vectorBasedManhattan(inputRNA,targetRNA, Main.USE_MANH_TF, Main.USE_MANH_IDF);
        System.out.println("- Vector based Manhattan distance : "+ manhRes.similarity + " (Tp= "+ manhRes.processingTime+" "+timeUnit+" , Tc= "+ manhRes.computationTime +" "+timeUnit+")");

        SimilarityResult pccRes = VectorBasedSim.vectorBasedPCC(inputRNA,targetRNA, Main.USE_PCC_TF, Main.USE_PCC_IDF);
        System.out.println("- Vector based PCC : "+ pccRes.similarity + " (Tp= "+ pccRes.processingTime+" "+timeUnit+" , Tc= "+ pccRes.computationTime +" "+timeUnit+")");

        ArrayList<ArrayList<SearchResult>> searchResults = SearchEngine.search(
                "ACCU",
                Main.USE_EDIT_DISTANCE,
                Main.USE_INTERSECTION,Main.USE_JACCARD,Main.USE_DICE,
                Main.USE_COSINE,Main.USE_EUCLIDEAN,Main.USE_MANHATTAN,Main.USE_PCC,
                Main.MIN_SIMILARITY, Main.K
        );

        for(int i=0; i < searchResults.size(); i++) {
            String sim = "";
            switch(i) {
                case 0:
                    sim = "\nED results for \""+Main.SEARCH_TERM+"\":";
                    break;
                case 1:
                    sim = "\nIntr results for \""+Main.SEARCH_TERM+"\":";
                    break;
                case 2:
                    sim = "\nJacc results for \""+Main.SEARCH_TERM+"\":";
                    break;
                case 3:
                    sim = "\nDice results for \""+Main.SEARCH_TERM+"\":";
                    break;
                case 4:
                    sim = "\nCos results for \""+Main.SEARCH_TERM+"\":";
                    break;
                case 5:
                    sim = "\nEuc results for \""+Main.SEARCH_TERM+"\":";
                    break;
                case 6:
                    sim = "\nManh results for \""+Main.SEARCH_TERM+"\":";
                    break;
                case 7:
                    sim = "\nPCC results for \""+Main.SEARCH_TERM+"\":";
                    break;
                default:
                    break;
            }
            System.out.print(sim + " F: " +SearchEngine.F_VALUE[i]+" MAP: "+SearchEngine.MEAN_AVERAGE_PR[i] +" PR_R: { ");

            for(int x=0; x< SearchEngine.PR_R_GRAPH.get(i).size(); x++) {
                System.out.print("["+SearchEngine.PR_R_GRAPH.get(i).get(x).precision+", "+SearchEngine.PR_R_GRAPH.get(i).get(x).recall+"] ");
            }

            System.out.println("}");

            int nbRes = 0;
            for(int j=0; j < searchResults.get(i).size(); j++) {
                nbRes++;
                System.out.println((j+1)+" --> " +searchResults.get(i).get(j).sequence+" ("+searchResults.get(i).get(j).similarity+") " + searchResults.get(i).get(j).isRelevant);
            }
            if(nbRes == 0)
                System.out.println("--> No results found.");
        }
         */
    }

    public void start (Stage primaryStage) throws Exception {
        Parent root = FXMLLoader.load(getClass().getResource("sample.fxml"));
        primaryStage.setTitle("RNA Similarity Evaluation");
        primaryStage.setScene(new Scene(root,1560,830));
        primaryStage.show();
        primaryStage.setResizable(false);
        RadioButton nanoSec, microSec , milliSec , Sec ;
    }



/////////////////////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////////////////////
///////////////////CREATING THE RNA DATABASE AND THE PRE-PROCESSING OF THE TF-IDFs VECTORS //
/////////////////////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////////////////////
    static void XMLfill(int minDBSeqSize, int maxDBSeqSize) {
        try {
            DocumentBuilderFactory documentFactory = DocumentBuilderFactory.newInstance();
            DocumentBuilder documentBuilder = documentFactory.newDocumentBuilder();
            Document RNAXML = documentBuilder.newDocument();

            Element root = RNAXML.createElement("RNAdb");
            RNAXML.appendChild(root);

            char[] literals = {'A','C','G','U','M','N','V','R','S'};
            String seq = "";
            String [] seqs= new String[Main.DB_SIZE];
            int[][] DFs = new int[Main.DB_SIZE][4];
            double[][] inputTFs = new double[Main.DB_SIZE][4];
            for(int j=0; j<Main.DB_SIZE ; j++ ){
                int len = (int) ((Math.random()*((maxDBSeqSize+1)-minDBSeqSize))+minDBSeqSize);

                for ( int i=0 ; i<len ; i++){
                    int index = (int) (Math.random()*9);
                    seq+= literals[index]+"";

                }

                Attr attr = RNAXML.createAttribute("id");
                attr.setValue(j+"");
                Element sequence = RNAXML.createElement(seq) ;
                sequence.setAttributeNode(attr);
                root.appendChild(sequence);
                seqs[j]=seq;

                inputTFs[j] = Frequency.mults(seq);

                for (int i = 0; i < inputTFs[j].length; i++) {
                    if(DFs[j][i] == 0) {
                        DFs[j][i] = 1;
                    }
                    if (inputTFs[j][i] > 0) {
                        DFs[j][i]++;
                    }
                }
                seq="";
            }
            NodeList nl = root.getChildNodes();
            for(int j=0 ; j<Main.DB_SIZE ; j++ ){
                Element litElem=null ;
                for(int i=0 ; i<4 ; i++ ){
                    inputTFs[j][i] = inputTFs[j][i] * Math.log(Main.DB_SIZE / DFs[j][i]);

                    char lit=' ';
                    switch (i){
                        case 0:
                            lit = 'A';
                            break;
                        case 1:
                            lit = 'C';
                            break;
                        case 2:
                            lit = 'G';
                            break;
                        case 3:
                            lit = 'U';
                            break;
                        default:
                            break;
                    }
                    litElem = RNAXML.createElement(lit+"");
                    litElem.appendChild(RNAXML.createTextNode(inputTFs[j][i]+""));
                    nl.item(j).appendChild(litElem);
                }
            }

            TransformerFactory transformerFactory = TransformerFactory.newInstance();
            Transformer transformer = transformerFactory.newTransformer();
            DOMSource source = new DOMSource(RNAXML);
            StreamResult result = new StreamResult(new File(Main.DB_PATH));
            transformer.transform(source, result);

            // Output to console for testing
            StreamResult consoleResult = new StreamResult(System.out);
            transformer.transform(source, consoleResult);

        } catch(Exception e){
            e.printStackTrace();
        }
    }

}



 