package sample;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import java.io.File;
import java.util.ArrayList;

public class SearchEngine {

    static public double[] F_VALUE = new double[8];
    static public ArrayList<ArrayList<PrecisionRecall>> PR_R_GRAPH = new ArrayList<ArrayList<PrecisionRecall>>();
    static public double[] MEAN_AVERAGE_PR = new double[8];

    public SearchEngine() {

    }

    static public ArrayList<ArrayList<SearchResult>> search(String input,
                                                      boolean editDistance,
                                                      boolean intersection, boolean jaccard, boolean dice,
                                                      boolean cosine, boolean euclidean, boolean manhattan, boolean pcc,
                                                      double minSimilarity, int k){
        for(int i=0; i< 8; i++) {
            SearchEngine.F_VALUE[i] = 0;
            SearchEngine.MEAN_AVERAGE_PR[i] = 0;
        }
        SearchEngine.PR_R_GRAPH.clear();

        ArrayList<String> resultED = null;
        ArrayList<Double> resultEDSims = null;
        ArrayList<Boolean> resultEDRel = null;

        ArrayList<String> resultInter = null;
        ArrayList<Double> resultInterSims = null;
        ArrayList<Boolean> resultInterRel = null;

        ArrayList<String> resultJaccard = null;
        ArrayList<Double> resultJaccardSims = null;
        ArrayList<Boolean> resultJaccardRel = null;

        ArrayList<String> resultDice = null;
        ArrayList<Double> resultDiceSims = null;
        ArrayList<Boolean> resultDiceRel = null;

        ArrayList<String> resultCos = null;
        ArrayList<Double> resultCosSims = null;
        ArrayList<Boolean> resultCosRel = null;

        ArrayList<String> resultEuc = null;
        ArrayList<Double> resultEucSims = null;
        ArrayList<Boolean> resultEucRel = null;

        ArrayList<String> resultManh = null;
        ArrayList<Double> resultManhSims = null;
        ArrayList<Boolean> resultManhRel = null;

        ArrayList<String> resultPcc = null;
        ArrayList<Double> resultPccSims = null;
        ArrayList<Boolean> resultPccRel = null;

        int edTP = 0, edFN = 0, edFP = 0, edTPFN = 0;
        int intTP = 0, intFN = 0, intFP = 0, intTPFN = 0;
        int jacTP = 0, jacFN = 0, jacFP = 0, jacTPFN = 0;
        int diceTP = 0, diceFN = 0, diceFP = 0, diceTPFN = 0;
        int cosTP = 0, cosFN = 0, cosFP = 0, cosTPFN = 0;
        int eucTP = 0, eucFN = 0, eucFP = 0, eucTPFN = 0;
        int manhTP = 0, manhFN = 0, manhFP = 0, manhTPFN = 0;
        int pccTP = 0, pccFN = 0, pccFP = 0, pccTPFN = 0;
        

        try {
            File inputFile = new File(Main.DB_PATH);
            DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
            DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
            Document doc = dBuilder.parse(inputFile);
            doc.getDocumentElement().normalize();
            NodeList nl = doc.getElementsByTagName("RNAdb").item(0).getChildNodes();

            String[] sequences = new String[Main.DB_SIZE];

            double[] edSims = new double[Main.DB_SIZE];
            boolean[] edRels = new boolean[Main.DB_SIZE];

            double[] interSims = new double[Main.DB_SIZE];
            boolean[] interRels = new boolean[Main.DB_SIZE];

            double[] jaccardSims = new double[Main.DB_SIZE];
            boolean[] jaccardRels = new boolean[Main.DB_SIZE];

            double[] diceSims = new double[Main.DB_SIZE];
            boolean[] diceRels = new boolean[Main.DB_SIZE];

            double[] cosSims = new double[Main.DB_SIZE];
            boolean[] cosRels = new boolean[Main.DB_SIZE];

            double[] euclSims = new double[Main.DB_SIZE];
            boolean[] euclRels = new boolean[Main.DB_SIZE];

            double[] manhSims = new double[Main.DB_SIZE];
            boolean[] manhRels = new boolean[Main.DB_SIZE];

            double[] pccSims = new double[Main.DB_SIZE];
            boolean[] pccRels = new boolean[Main.DB_SIZE];


            for (int i=0 ; i<Main.DB_SIZE ; i++){
                Element[] elements = new Element[4];
                double a=0, c=0, g=0, u=0 ;
                for ( int j=0 ; j<4 ; j++){
                   elements[j]= (Element) nl.item(i).getChildNodes().item(j);
                   switch(elements[j].getNodeName()){
                       case "A":
                           a= Double.parseDouble(elements[j].getChildNodes().item(0).getNodeValue());
                           break;
                       case "C":
                           c= Double.parseDouble(elements[j].getChildNodes().item(0).getNodeValue());
                           break;
                       case "G":
                           g= Double.parseDouble(elements[j].getChildNodes().item(0).getNodeValue());
                           break;
                       case "U":
                           u= Double.parseDouble(elements[j].getChildNodes().item(0).getNodeValue());
                           break;
                       default:
                           break;
                   }
                }

                sequences[i]=nl.item(i).getNodeName();

                if(editDistance){
                    edSims[i]=EditDistanceSim.getSimilarityED(input,sequences[i],Main.INSERT_WEIGHT_SE,Main.DELETE_WEIGHT_SE,Main.UPDATE_WEIGHT_SE).similarity;
                    edRels[i]= isRelevant(input,sequences[i]);
                    edTPFN += edRels[i] ? 1 : 0;
                    if (resultED == null){
                        resultED = new ArrayList<String>();
                        resultEDSims = new ArrayList<Double>();
                        resultEDRel = new ArrayList<Boolean>();
                        resultED.add(0, sequences[i]);
                        resultEDSims.add(0,edSims[i]);
                        resultEDRel.add(0,edRels[i]);
                    } else {
                        SearchEngine.processSim(edSims[i], sequences[i], edRels[i], resultED, resultEDSims, resultEDRel);
                    }
                }
                
                if(intersection){
                    interSims[i]=SetBasedSim.setBasedInter(input,a,c,g,u);
                    interRels[i]= isRelevant(input,sequences[i]);
                    intTPFN += interRels[i] ? 1 : 0;
                    if (resultInter == null){
                        resultInter = new ArrayList<String>();
                        resultInterSims = new ArrayList<Double>();
                        resultInterRel = new ArrayList<Boolean>();
                        resultInter.add(0, sequences[i]);
                        resultInterSims.add(0,interSims[i]);
                        resultInterRel.add(0, interRels[i]);
                    }
                    else {
                        SearchEngine.processSim(interSims[i], sequences[i], interRels[i], resultInter, resultInterSims, resultInterRel);
                    }
                }
                if(jaccard){
                    jaccardSims[i]=SetBasedSim.setBasedJaccard(input,a,c,g,u);
                    jaccardRels[i]= isRelevant(input,sequences[i]);
                    jacTPFN += jaccardRels[i] ? 1 : 0;
                    if (resultJaccard == null){
                        resultJaccard = new ArrayList<String>();
                        resultJaccardSims = new ArrayList<Double>();
                        resultJaccardRel = new ArrayList<Boolean>();
                        resultJaccard.add(0, sequences[i]);
                        resultJaccardSims.add(0,jaccardSims[i]);
                        resultJaccardRel.add(0, jaccardRels[i]);
                    }
                    else {
                        SearchEngine.processSim(jaccardSims[i], sequences[i], jaccardRels[i], resultJaccard, resultJaccardSims, resultJaccardRel);
                    }
                }
                if(dice){
                    diceSims[i]=SetBasedSim.setBasedDice(input,a,c,g,u);
                    diceRels[i]= isRelevant(input,sequences[i]);
                    diceTPFN += diceRels[i] ? 1 : 0;
                    if (resultDice == null){
                        resultDice = new ArrayList<String>();
                        resultDiceSims = new ArrayList<Double>();
                        resultDiceRel = new ArrayList<Boolean>();
                        resultDice.add(0, sequences[i]);
                        resultDiceSims.add(0,diceSims[i]);
                        resultDiceRel.add(0, diceRels[i]);
                    }
                    else {
                        SearchEngine.processSim(diceSims[i], sequences[i], diceRels[i], resultDice, resultDiceSims, resultDiceRel);
                    }
                }
                if(cosine){
                    cosSims[i]=VectorBasedSim.vectorBasedCosine(input,a,c,g,u);
                    cosRels[i]= isRelevant(input,sequences[i]);
                    cosTPFN += cosRels[i] ? 1 : 0;
                    if (resultCos == null){
                        resultCos = new ArrayList<String>();
                        resultCosSims = new ArrayList<Double>();
                        resultCosRel = new ArrayList<Boolean>();
                        resultCos.add(0, sequences[i]);
                        resultCosSims.add(0,cosSims[i]);
                        resultCosRel.add(0, cosRels[i]);
                    }
                    else {
                        SearchEngine.processSim(cosSims[i], sequences[i], cosRels[i], resultCos, resultCosSims, resultCosRel);
                    }
                }
                if(euclidean){
                    euclSims[i]=VectorBasedSim.vectorBasedEuclidean(input,a,c,g,u);
                    euclRels[i]= isRelevant(input,sequences[i]);
                    eucTPFN += euclRels[i] ? 1 : 0;
                    if (resultEuc == null){
                        resultEuc = new ArrayList<String>();
                        resultEucSims = new ArrayList<Double>();
                        resultEucRel = new ArrayList<Boolean>();
                        resultEuc.add(0, sequences[i]);
                        resultEucSims.add(0,euclSims[i]);
                        resultEucRel.add(0, euclRels[i]);
                    }
                    else {
                        SearchEngine.processSim(euclSims[i], sequences[i], euclRels[i], resultEuc, resultEucSims, resultEucRel);
                    }
                }
                if(manhattan){
                    manhSims[i]=VectorBasedSim.vectorBasedManhattan(input,a,c,g,u);
                    manhRels[i]= isRelevant(input,sequences[i]);
                    manhTPFN += manhRels[i] ? 1 : 0;
                    if (resultManh == null){
                        resultManh = new ArrayList<String>();
                        resultManhSims = new ArrayList<Double>();
                        resultManhRel = new ArrayList<Boolean>();
                        resultManh.add(0, sequences[i]);
                        resultManhSims.add(0,manhSims[i]);
                        resultManhRel.add(0, manhRels[i]);
                    }
                    else {
                        SearchEngine.processSim(manhSims[i], sequences[i], manhRels[i], resultManh, resultManhSims, resultManhRel);
                    }
                }
                if(pcc){
                    pccSims[i]=VectorBasedSim.vectorBasedPCC(input,a,c,g,u);
                    pccRels[i]= isRelevant(input,sequences[i]);
                    pccTPFN += pccRels[i] ? 1 : 0;
                    if (resultPcc == null){
                        resultPcc = new ArrayList<String>();
                        resultPccSims = new ArrayList<Double>();
                        resultPccRel = new ArrayList<Boolean>();
                        resultPcc.add(0, sequences[i]);
                        resultPccSims.add(0,pccSims[i]);
                        resultPccRel.add(0, pccRels[i]);
                    }
                    else {
                        SearchEngine.processSim(pccSims[i], sequences[i], pccRels[i], resultPcc, resultPccSims, resultPccRel);
                    }
                }
            }
        } catch(Exception e){
            ArrayList<ArrayList<SearchResult>> toReturn = new ArrayList<ArrayList<SearchResult>>();
            toReturn.add(0,new ArrayList<SearchResult>());
            toReturn.add(1,new ArrayList<SearchResult>());
            toReturn.add(2,new ArrayList<SearchResult>());
            toReturn.add(3,new ArrayList<SearchResult>());
            toReturn.add(4,new ArrayList<SearchResult>());
            toReturn.add(5,new ArrayList<SearchResult>());
            toReturn.add(6,new ArrayList<SearchResult>());
            toReturn.add(7,new ArrayList<SearchResult>());

            for(int i=0; i< 8; i++) {
                SearchEngine.F_VALUE[i] = 0;
                SearchEngine.MEAN_AVERAGE_PR[i] = 0;
            }
            SearchEngine.PR_R_GRAPH.clear();

            return toReturn;
        }

        ArrayList<SearchResult> resultEDK =  new ArrayList<SearchResult>();
        ArrayList<SearchResult> resultInterK = new ArrayList<SearchResult>();
        ArrayList<SearchResult> resultJaccardK = new ArrayList<SearchResult>();
        ArrayList<SearchResult> resultDiceK = new ArrayList<SearchResult>();
        ArrayList<SearchResult> resultCosK = new ArrayList<SearchResult>();
        ArrayList<SearchResult> resultEucK = new ArrayList<SearchResult>();
        ArrayList<SearchResult> resultManhK = new ArrayList<SearchResult>();
        ArrayList<SearchResult> resultPccK = new ArrayList<SearchResult>();

        for ( int i=0 ; i<k; i++){
            if(editDistance) {
                if(resultEDSims.get(i) >= minSimilarity) {
                    resultEDK.add(i, new SearchResult(resultED.get(i), resultEDSims.get(i), resultEDRel.get(i)));
                    if(resultEDRel.get(i))
                        edTP++;
                    else
                        edFP++;
                }
            }
            if(intersection) {
                if(resultInterSims.get(i) >= minSimilarity) {
                    resultInterK.add(i, new SearchResult(resultInter.get(i), resultInterSims.get(i), resultInterRel.get(i)));
                    if(resultInterRel.get(i))
                        intTP++;
                    else
                        intFP++;
                }
            }
            if(jaccard) {
                if(resultJaccardSims.get(i) >= minSimilarity) {
                    resultJaccardK.add(i, new SearchResult(resultJaccard.get(i), resultJaccardSims.get(i), resultJaccardRel.get(i)));
                    if(resultJaccardRel.get(i))
                        jacTP++;
                    else
                        jacFP++;
                }
            }
            if(dice) {
                if(resultDiceSims.get(i) >= minSimilarity) {
                    resultDiceK.add(i, new SearchResult(resultDice.get(i), resultDiceSims.get(i), resultDiceRel.get(i)));
                    if(resultDiceRel.get(i))
                        diceTP++;
                    else
                        diceFP++;
                }
            }
            if(cosine) {
                if(resultCosSims.get(i) >= minSimilarity) {
                    resultCosK.add(i, new SearchResult(resultCos.get(i), resultCosSims.get(i), resultCosRel.get(i)));
                    if(resultCosRel.get(i))
                        cosTP++;
                    else
                        cosFP++;
                }
            }
            if(euclidean) {
                if(resultEucSims.get(i) >= minSimilarity) {
                    resultEucK.add(i, new SearchResult(resultEuc.get(i), resultEucSims.get(i), resultEucRel.get(i)));
                    if(resultEucRel.get(i))
                        eucTP++;
                    else
                        eucFP++;
                }
            }
            if(manhattan) {
                if(resultManhSims.get(i) >= minSimilarity) {
                    resultManhK.add(i, new SearchResult(resultManh.get(i), resultManhSims.get(i), resultManhRel.get(i)));
                    if(resultManhRel.get(i))
                        manhTP++;
                    else
                        manhFP++;
                }
            }
            if(pcc) {
                if(resultPccSims.get(i) >= minSimilarity) {
                    resultPccK.add(i, new SearchResult(resultPcc.get(i), resultPccSims.get(i), resultPccRel.get(i)));
                    if(resultPccRel.get(i))
                        pccTP++;
                    else
                        pccFP++;
                }
            }

        }
        ArrayList<ArrayList<SearchResult>> toReturn = new ArrayList<ArrayList<SearchResult>>();
        toReturn.add(0,resultEDK);
        toReturn.add(1,resultInterK);
        toReturn.add(2,resultJaccardK);
        toReturn.add(3,resultDiceK);
        toReturn.add(4,resultCosK);
        toReturn.add(5,resultEucK);
        toReturn.add(6,resultManhK);
        toReturn.add(7,resultPccK);

        // Quality Evaluation
        edFN = edTPFN - edTP;
        intFN = intTPFN - intTP;
        jacFN = jacTPFN - jacTP;
        diceFN = diceTPFN - diceTP;
        cosFN = cosTPFN - cosTP;
        eucFN = eucTPFN - eucTP;
        manhFN = manhTPFN - manhTP;
        pccFN = pccTPFN - pccTP;

        //F-Value
        F_VALUE[0] = SearchEngine.FValue(resultEDK.size(), edTP,edFP,edFN);
        F_VALUE[1] = SearchEngine.FValue(resultInterK.size(), intTP,intFP,intFN);
        F_VALUE[2] = SearchEngine.FValue(resultJaccardK.size(), jacTP,jacFP,jacFN);
        F_VALUE[3] = SearchEngine.FValue(resultDiceK.size(), diceTP,diceFP,diceFN);
        F_VALUE[4] = SearchEngine.FValue(resultCosK.size(), cosTP,cosFP,cosFN);
        F_VALUE[5] = SearchEngine.FValue(resultEucK.size(), eucTP,eucFP,eucFN);
        F_VALUE[6] = SearchEngine.FValue(resultManhK.size(), manhTP,manhFP,manhFN);
        F_VALUE[7] = SearchEngine.FValue(resultPccK.size(), pccTP,pccFP,pccFN);

        //PR-R Graph
        PR_R_GRAPH.add(SearchEngine.precisionRecallGraph(resultEDK, edFN));
        PR_R_GRAPH.add(SearchEngine.precisionRecallGraph(resultInterK, intFN));
        PR_R_GRAPH.add(SearchEngine.precisionRecallGraph(resultJaccardK, jacFN));
        PR_R_GRAPH.add(SearchEngine.precisionRecallGraph(resultDiceK, diceFN));
        PR_R_GRAPH.add(SearchEngine.precisionRecallGraph(resultCosK, cosFN));
        PR_R_GRAPH.add(SearchEngine.precisionRecallGraph(resultEucK, eucFN));
        PR_R_GRAPH.add(SearchEngine.precisionRecallGraph(resultManhK, manhFN));
        PR_R_GRAPH.add(SearchEngine.precisionRecallGraph(resultPccK, pccFN));

        //MAP
        MEAN_AVERAGE_PR[0] = SearchEngine.meanAveragePrecision(resultEDK, edTPFN);
        MEAN_AVERAGE_PR[1] = SearchEngine.meanAveragePrecision(resultInterK, intTPFN);
        MEAN_AVERAGE_PR[2] = SearchEngine.meanAveragePrecision(resultJaccardK, jacTPFN);
        MEAN_AVERAGE_PR[3] = SearchEngine.meanAveragePrecision(resultDiceK, diceTPFN);
        MEAN_AVERAGE_PR[4] = SearchEngine.meanAveragePrecision(resultCosK, cosTPFN);
        MEAN_AVERAGE_PR[5] = SearchEngine.meanAveragePrecision(resultEucK, eucTPFN);
        MEAN_AVERAGE_PR[6] = SearchEngine.meanAveragePrecision(resultManhK, manhTPFN);
        MEAN_AVERAGE_PR[7] = SearchEngine.meanAveragePrecision(resultPccK, pccTPFN);

        return toReturn;
    }

    static public void processSim(double sim, String dbSequence, boolean isRel, ArrayList<String> resultList, ArrayList<Double> resultListSim, ArrayList<Boolean> resultListRel) {
        int s = resultList.size();
        for (int x = 0; x < resultList.size(); x++) {
            if (sim >= resultListSim.get(x)) {
                resultListSim.add(x,sim);
                resultList.add(x,dbSequence);
                resultListRel.add(x, isRel);
                break;
            }
        }
        if (s == resultList.size()){
            resultListSim.add(resultListSim.size(), sim);
            resultList.add(resultList.size(),dbSequence);
            resultListRel.add(resultListRel.size(), isRel);
        }

    }

    static public boolean isRelevant(String input, String result) {
        if (input.length() > result.length()) {
            String temp = new String(input);
            input = new String(result);
            result = new String(temp);
        }
        for (int x = 0; x <= result.length() - input.length(); x++) {
            for (int i = 0; i < input.length(); i++) {
                char ch1 = input.charAt(i);
                Literal litInp = new Literal(ch1);
                String inp_representative = litInp.getCanBe() + ch1;

                char ch2 = result.charAt(i);
                Literal litRes = new Literal(ch2);
                String res_representative = litRes.getCanBe() + ch2;

                boolean contains = true;
                for (int j = 0; j < res_representative.length(); j++) {
                    if (!inp_representative.contains(res_representative.charAt(j) + "")) {
                        contains = false;
                        break;
                    }
                }
                if (contains)
                    return true;
            }
        }
        return false;
    }

    static public double precision(int TP, int FP) {
        return (double)TP/(TP+FP);
    }
    static public double recall(int TP, int FN) {
        return (double)TP/(TP+FN);
    }

    static public double FValue(int size, int TP, int FP, int FN) {
        if(size == 0)
            return 0;

        double precision = SearchEngine.precision(TP,FP);
        double recall = SearchEngine.recall(TP,FN);
        return (2*precision*recall) / (precision+recall);
    }

    static public ArrayList<PrecisionRecall> precisionRecallGraph(ArrayList<SearchResult> resultListK, int FN) {
        if(resultListK.size() == 0)
            return new ArrayList<PrecisionRecall>();

        int tempTP = 0;

        ArrayList<PrecisionRecall> toReturn = new ArrayList<PrecisionRecall>();

        for(int i=0; i< resultListK.size(); i++) {
            if(resultListK.get(i).isRelevant)
                tempTP++;
            toReturn.add(new PrecisionRecall(SearchEngine.precision(tempTP, (i+1)-tempTP), SearchEngine.recall(tempTP, FN-((i+1)-tempTP))));
        }

        return toReturn;
    }

    static public double meanAveragePrecision(ArrayList<SearchResult> resultListK, int TPFN) {
        if(resultListK.size() == 0)
            return 0;

        int tempTP = 0;
        double MAP = 0;

        for(int i=0; i< resultListK.size(); i++) {
            if(resultListK.get(i).isRelevant) {
                tempTP++;
                MAP += SearchEngine.precision(tempTP, (i+1)-tempTP);
            }
        }

        MAP /= TPFN;

        return MAP;
    }


}
