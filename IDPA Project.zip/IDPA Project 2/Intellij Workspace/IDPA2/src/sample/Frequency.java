package sample;

public class Frequency {

    public Frequency(){

    }
    static double[] mults(String input) {
        double[] arrInput = new double[4];
        for (int i = 0; i < input.length(); i++) {
            switch (input.charAt(i)) {
                case 'A':
                    arrInput[0]++;
                    break;
                case 'C':
                    arrInput[1]++;
                    break;
                case 'G':
                    arrInput[2]++;
                    break;
                case 'U':
                    arrInput[3]++;
                    break;
                case 'R':
                    arrInput[0] += 0.5;
                    arrInput[2] += 0.5;
                    break;
                case 'M':
                    arrInput[0] += 0.5;
                    arrInput[1] += 0.5;
                    break;
                case 'S':
                    arrInput[1] += 0.5;
                    arrInput[2] += 0.5;
                    break;
                case 'V':
                    arrInput[0] += 0.333;
                    arrInput[1] += 0.333;
                    arrInput[2] += 0.333;
                    break;
                case 'N':
                    arrInput[0] += 0.25;
                    arrInput[1] += 0.25;
                    arrInput[2] += 0.25;
                    arrInput[3] += 0.25;
                    break;
                default:
                    break;
            }
        }
        return arrInput;

    }

}
